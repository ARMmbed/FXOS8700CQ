FXOS8700CQ - FXOS8700CQ library for motion detection (accelerometer) for K64F
